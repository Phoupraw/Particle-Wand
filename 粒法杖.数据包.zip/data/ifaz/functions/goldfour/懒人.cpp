#include <cstdio>
#include <direct.h>
#include <cmath>
using namespace std;

const double PI = 3.141592654, MIND = 0.1,
    cols[7][3] = {
        {1, 0, 0},
        {1, 0.5, 0},
        {1, 1, 0},
        {0, 1, 0},
        {0.5, 1, 1},
        {0, 0, 1},
        {1, 0, 1}
    };
double dxyz[10] = {-1.5, 1.5};
char cr1[300]/*文件名*/;

int main() {
    freopen("懒人.txt", "w", stdout);

    // 画立方体框
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (double k = -1.5; k <= 1.5; k += 0.1) {
                printf("particle dust 1 0.9 0 1 ^%.1lf ^%.1lf ^%.1lf 0 0 0 0 1 force\n", dxyz[i], dxyz[j], k);
                printf("particle dust 1 0.9 0 1 ^%.1lf ^%.1lf ^%.1lf 0 0 0 0 1 force\n", dxyz[i], k, dxyz[j]);
                printf("particle dust 1 0.9 0 1 ^%.1lf ^%.1lf ^%.1lf 0 0 0 0 1 force\n", k, dxyz[i], dxyz[j]);
            }
    
    // 画射线
    for (double i = -4; i <= 4; i += 0.1) {
        printf("particle dust 1 0.5 0 1 ^%.1lf ^ ^ 0 0 0 0 1 force\n", i);
        printf("particle dust 1 0.5 0 1 ^ ^%.1lf ^ 0 0 0 0 1 force\n", i);
        printf("particle dust 1 0.5 0 1 ^ ^ ^%.1lf 0 0 0 0 1 force\n", i);
    }
    return 0;
}