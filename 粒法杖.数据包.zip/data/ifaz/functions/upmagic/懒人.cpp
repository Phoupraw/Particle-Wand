#include <cstdio>
#include <direct.h>
#include <cmath>
using namespace std;

const double PI = 3.141592654;

int main() {
    freopen("懒人.txt", "w", stdout);
    int jm = 32;
    double r = 1;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < jm; j++) {
            printf("particle dust 1 0 0.5 1 ~%lf ~%lf ~%lf 0 0 0 0 1 force\n", cos(2 * PI * j / jm) * r, r - 1, sin(2 * PI * j / jm) * r);
        }
        jm += 32;
        r += 1;
    }
    return 0;
}