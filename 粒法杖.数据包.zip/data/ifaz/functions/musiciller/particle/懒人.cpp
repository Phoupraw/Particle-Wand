#include <cstdio>
#include <direct.h>
#include <cmath>
using namespace std;

const double PI = 3.141592654,
    cols[7][3] = {
        {1, 0, 0},
        {1, 0.5, 0},
        {1, 1, 0},
        {0, 1, 0},
        {0.5, 1, 1},
        {0, 0, 1},
        {1, 0, 1}
    };
char cr1[300]/*文件名*/;

int main() {
    int jm = 64;
    double r = 2;
    for (int i = 0; i < 7; i++) {
        sprintf(cr1, "%d.mcfunction", i * 2);
        freopen(cr1, "w", stdout);
        for (int j = 0; j < jm; j++) {
            printf("particle dust %.1lf %.1lf %.1lf 1 ~%lf ~ ~%lf 0 0 0 0 1 force\n", cols[i][0], cols[i][1], cols[i][2], cos(2 * PI * j / jm) * r, sin(2 * PI * j / jm) * r);
        }
        jm += 64;
        sprintf(cr1, "%d.mcfunction", i * 2 + 1);
        freopen(cr1, "w", stdout);
        for (int j = 0; j < jm; j++) {
            printf("particle dust %.1lf %.1lf %.1lf 1 ~%lf ~%lf ~%lf 0 0 0 0 1 force\n", cols[i][0], cols[i][1], cols[i][2], cos(2 * PI * j / jm) * r, (sin(8 * PI * j / jm + PI / 2 * i) + 0.5 * sin(8 * PI * j / jm + PI / 2 * i + PI / 2)) * r, sin(2 * PI * j / jm) * r);
        }
        r += 2;
    }
    return 0;
}