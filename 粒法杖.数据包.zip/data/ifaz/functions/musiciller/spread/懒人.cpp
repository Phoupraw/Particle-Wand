#include <cstdio>
#include <direct.h>
#include <cmath>
using namespace std;

double pit[25];
char cr1[300]/*文件名*/;

int main() {
    //先计算好音调
    for (int i = 0; i < 25; i++) {
        pit[i] = pow(2, (i - 12) / 12.0);
    }
    for (int i = 0; i < 14; i++) {
        sprintf(cr1, "%d.mcfunction", i);
        freopen(cr1, "w", stdout);
        printf("function ifaz:musiciller/particle/%d\n", i);
        printf("execute store result score &present_uuid ifaz_calc run scoreboard players get @s ifaz_to_uuidll\n");
        printf("execute as @e[type=!#ifaz:ndamage,distance=..%d] unless score @s ifaz_uuidll = &present_uuid ifaz_calc at @s run tp ~ ~%d ~\n", i + 2, i + 1);
        printf("playsound minecraft:block.note_block.flute player @a ~ ~ ~ 16 %lf\n", pit[i + 11]);
    }
    return 0;
}