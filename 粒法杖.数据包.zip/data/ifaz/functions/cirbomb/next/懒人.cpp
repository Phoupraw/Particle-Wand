#include <cstdio>
#include <direct.h>
#include <cmath>
using namespace std;

const double PI = 3.141592654, R = 0.3;
char cr1[300]/*文件名*/;

int main() {
    for (int i = 0; i < 32; i++) {
        sprintf(cr1, "%d.mcfunction", i);
        freopen(cr1, "w", stdout);
        printf("particle crit ^%lf ^%lf ^ 0 0 0 0 1 force\n", cos(2 * PI * i / 32) * R, sin(2 * PI * i / 32) * R);
        if (i < 31)
            printf("execute positioned ^ ^ ^0.015 run function ifaz:cirbomb/next/%d\n", i + 1);
    }
    return 0;
}